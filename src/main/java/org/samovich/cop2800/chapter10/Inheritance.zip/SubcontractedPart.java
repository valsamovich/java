/*
 * AUTHOR:	R Grant
 * DATE:	3/2014
 */
public class SubcontractedPart extends ManufacturedPart
{
	private String processDescription;//description of what is done to this part
	private double subcontractCost;//cost for outside company to do this process
	public static final String DEFAULT_PROCESS_DESCRIPTION = "no process description";
	
	public SubcontractedPart(int id)     //create minimal object
	{
		this(id, DEFAULT_PROCESS_DESCRIPTION, 0);
	}
	
	public SubcontractedPart(int id, String processDesc, double sCost) 
	{
		super (id, 0, 0);  //call ManufacturedPart ctor
		this.setProcessDescription(processDesc);
		this.setSubcontractCost(sCost);
	}

	public SubcontractedPart(int id, String partDesc, double sellPrice,   //for Part object
			double  lCost, double mCost,  //for ManufacturedCost object
			String processDesc, double sCost)  //for SubcontractedPArt object
	{
		super(id,  //for Part
				partDesc, //
				sellPrice, //part price
				lCost, //description for part
				mCost);   //selling price of part
		this.setProcessDescription(processDesc);
		this.setSubcontractCost(sCost);
	}
	public String getProcessDescription() 
	{
		return processDescription;
	}
	public void setProcessDescription(String newProcessDescription) 
	{
		if (newProcessDescription != null)
			processDescription = newProcessDescription;
	}
	public double getSubcontractCost() 
	{
		return subcontractCost;
	}
	public void setSubcontractCost(double newSubcontractCost) 
	{
		if (newSubcontractCost >= 0)
			subcontractCost = newSubcontractCost;
	}
	public String toString()
	{
		return super.toString() + "\n" +
				"\tProcess Description: " + this.getProcessDescription()  + "\n" +
				"\tSubcontract Cost: " + this.getSubcontractCost();
	}
}
