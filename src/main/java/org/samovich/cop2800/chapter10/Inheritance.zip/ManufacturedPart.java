/*
 * AUTHOR:	R Grant
 * DATE:	3/2014
 */
public class ManufacturedPart extends Part
{
	private double laborCost;//cost to make part (hours * rate)
	private double materialCost;//amount of material in product
	
	public ManufacturedPart(int id)
	{
		this(id, 0, 0);
	}
	public ManufacturedPart(int id, double lCost, double mCost)
	{
		this(id, Part.DEFAULT_PART_DESCRIPTION, 0,   //arguments for superclass
				lCost, mCost);
	}
	public ManufacturedPart(int id, String desc, double sellPrice,  //for superclass object
			double lCost, double mCost)  //for this object
	{
		super(id, desc, sellPrice);
		this.setLaborCost(lCost);
		this.setMaterialCost(mCost);
	}
	public double getLaborCost() 
	{
		return laborCost;
	}
	public void setLaborCost(double laborCost) 
	{
		if (laborCost >= 0)
			this.laborCost = laborCost;
	}
	public double getMaterialCost() 
	{
		return materialCost;
	}
	public void setMaterialCost(double materialCost) 
	{
		if (materialCost >= 0)
			this.materialCost = materialCost;
	}	
	public String toString()
	{
		return super.toString() + "\n" +
				"\tLabor Cost: " + this.getLaborCost() + "\n" +
				"\tMaterial Cost: " + this.getMaterialCost();
	}
}
